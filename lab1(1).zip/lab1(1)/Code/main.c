#include<stdio.h>
/*
 * 头文件包含:
 * - stdio.h: 提供输入输出功能，如 printf 和 perror。
 * - tree.h: 定义语法树结构和相关函数。
 */
#include"tree.h"
/*
 * 文件: main.c
 * 说明:
 * - 该文件是编译器前端的主程序，负责调用词法分析器和语法分析器。
 * - 主要流程包括读取输入文件、初始化词法分析器、执行语法分析，并在无错误时打印语法树。
 */
void perror(const char *__s);
/*
 * 函数声明:
 * - perror: 打印错误信息。
 * - yyrestart: 重新启动词法分析器，使其从指定文件读取输入。
 * - yyparse: 调用 Bison 生成的语法分析器，执行解析过程。
 */
int yyrestart();
int yyparse();
//int yydebug;
int error = 0;
/*
 * 全局变量:
 * - error: 记录词法和语法分析中的错误数量。
 * - Root: 语法树的根节点。
 * - yylineo: 记录当前处理的行号（应为 yylineno）。
 */
Node * Root = NULL;
extern void printTree(Node *root,int number);
extern int yylineo;
/*
 * 函数: main
 * 作用:
 * - 解析命令行参数，打开输入文件并初始化词法分析器。
 * - 调用语法分析器，并在无错误时打印语法树。
 * 参数:
 * - argc: 命令行参数个数。
 * - argv: 命令行参数数组，argv[1] 为输入文件路径。
 * 返回:
 * - 成功返回 0，失败返回 1。
 */
int main(int argc, char** argv) 
{
  // 检查是否提供了输入文件，若无则返回 1 终止程序
  if(argc <=1) return 1;
  // 打开输入文件以读取源代码
  FILE* f = fopen(argv[1], "r");
  // 若文件打开失败，则打印错误信息并终止程序
  if (!f)
  {
      perror(argv[1]);
      return 1;
  }
  // 重新启动词法分析器，使其从输入文件读取内容
  yyrestart(f);
  //yydebug = 1;
  // 调用 Bison 语法分析器执行解析
  yyparse();
  // 若语法分析过程中未出现错误，则打印语法树
  if(error == 0)
  {
      // 递归打印语法树，层级结构通过缩进表示
      printTree(Root,0);
  }
  // 解析完成后正常退出
  return 0;
}

/*
 * 编译和运行说明:
 * - 使用 Flex 生成词法分析器。
 * - 使用 Bison 生成语法分析器，并进行编译和链接。
 * - 需要安装 libbison-dev 以支持 Bison 解析。
 */
/*
flex lexical.l
gcc main.c lex.yy.c -lfl -o scanner
./scanner ../Test/test1.cmm

bison -d syntax.y 这个参数的含义是，将编译的结果分拆成syntax.tab.c和syntax.tab.h两个文件，其中.h文
件里包含着一些词法单元的类型定义之类的内容。
flex lexical.l
gcc main.c syntax.tab.c -lfl -ly -o parser
sudo apt-get install libbison-dev
./parser ../Test/test1.cmm
*/