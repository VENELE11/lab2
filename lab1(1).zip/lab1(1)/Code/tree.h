/**********************************************
 * 文件: tree.h
 * 说明:
 * - 定义语法树的基本数据结构及相关操作。
 * - 提供节点创建、子节点添加、语法树打印的函数声明。
 **********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

/*
 * 头文件包含:
 * - stdio.h: 提供输入输出函数，如 printf。
 * - stdlib.h: 提供内存管理和转换函数，如 malloc, free。
 * - string.h: 提供字符串操作函数，如 strcpy。
 * - stdarg.h: 提供可变参数处理功能，用于 addNode 函数。
 */

extern int yylineno;
/*
 * 记录当前处理的代码行号。
 * 由词法分析器维护，用于错误报告。
 */

struct Node{
    /*
     * 结构体: Node
     * 说明:
     * - 语法树的基本节点结构，表示一个语法单元。
     * 成员:
     * - name: 语法单元的名称（如 ID, INT, FLOAT）。
     * - yytext: 词法分析器提供的文本值。
     * - child: 指向子节点的指针数组，最多支持 10 个子节点。
     * - childno: 当前节点的子节点数量。
     * - lineno: 该节点在源代码中的行号。
     */
    char name[32];
    char yytext[32];
    struct Node *child[10];
    int childno;
    int lineno;
};
typedef struct Node Node;
/*
 * 定义 Node 类型别名，方便后续使用。
 */

Node* createNode(char* name, char* text);
/*
 * 函数: createNode
 * 作用:
 * - 创建一个新的语法树节点。
 * 参数:
 * - name: 语法单元名称。
 * - text: 词法分析器提供的文本值。
 * 返回:
 * - 返回一个新创建的节点指针。
 */

void addNode(int childsum, Node* parent, ...);
/*
 * 函数: addNode
 * 作用:
 * - 将多个子节点添加到父节点。
 * 参数:
 * - childsum: 子节点数量。
 * - parent: 父节点指针。
 * - ...: 可变参数，表示多个子节点。
 */

void printTree(Node *root,int number);
/*
 * 函数: printTree
 * 作用:
 * - 递归打印语法树，缩进表示层级结构。
 * 参数:
 * - root: 语法树的根节点。
 * - number: 当前缩进层级，用于打印格式化输出。
 */
