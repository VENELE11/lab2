#include "tree.h"

/*
 * 文件: tree.c
 * 说明:
 * - 实现语法树的节点创建、添加子节点、打印树结构的功能。
 * - 使用变长参数列表（va_list）来支持动态添加子节点。
 */

Node* createNode(char* name,char * yytext)
{
    /*
     * 函数: createNode
     * 作用:
     * - 创建语法树的节点并初始化相关属性。
     * 参数:
     * - name: 语法单元的名称（如 ID, INT, FLOAT）。
     * - yytext: 词法分析器的文本值。
     * 返回:
     * - 返回一个新创建的节点指针。
     */
    Node *p = (Node*)malloc(sizeof(Node));
    strcpy(p->name, name);
    strcpy(p->yytext,yytext);
    p->lineno = yylineno;
    for(int i=0;i<10;i++){
        p->child[i] = NULL;
    }
    p->childno = 0;
    return p;
}

void addNode(int childno, Node* parent, ...){
    /*
     * 函数: addNode
     * 作用:
     * - 将多个子节点添加到父节点。
     * 参数:
     * - childno: 子节点数量。
     * - parent: 父节点指针。
     * - ...: 可变参数，表示多个子节点。
     * 说明:
     * - 该函数使用 `va_list` 处理可变参数，实现动态子节点添加。
     */
    va_list ap; 
    va_start(ap,parent);
    parent ->childno = childno;
    for(int i=0; i<childno; i++)
    {
        parent->child[i] = va_arg(ap, Node*);
    }
    parent->lineno = parent->child[0]->lineno;
    va_end(ap);
}

void printTree(Node *root,int number){
    /*
     * 函数: printTree
     * 作用:
     * - 递归打印语法树，缩进表示层级结构。
     * 参数:
     * - root: 语法树的根节点。
     * - number: 当前缩进层级，用于打印格式化输出。
     * 说明:
     * - 叶子节点（如 ID、INT、FLOAT）会打印其文本值或数值。
     * - INT8 和 INT16 分别处理八进制和十六进制数的转换并打印。
     */
    if(root == NULL){
        // 如果根节点为空，则直接返回
        return;
    }
    for(int i=0;i<number;i++)
    {
        printf(" ");
    }
    
    if(root->childno!=0)
    {
        // 如果当前节点有子节点，则打印名称和行号，并递归打印子节点
        printf("%s (%d)\n", root->name, root->lineno);
        for(int i=0; i<root->childno; i++)
        {
            printTree(root->child[i],number+2);
        }
    }
    // 如果当前节点是词法单元（终结符），根据类型打印其值
    else
    {
        if(strcmp("ID",root->name) == 0)
        {
            // 如果是标识符（ID），打印其名称和值
            printf("%s: %s\n", root->name, root->yytext);
        }
        else if(strcmp("TYPE",root->name) == 0)
        {
            printf("%s: %s\n", root->name, root->yytext);
        }
        else if(strcmp("INT",root->name) == 0)
        {
            printf("%s: %d\n", root->name, atoi(root->yytext));
        }
        else if(strcmp("INT8",root->name) == 0)
        {
            // 处理八进制整数，转换为十进制并打印
            char * temp = root->yytext;
            temp++;
            char * end =NULL;
            int res = strtol(temp,&end,8);
            printf("%s: %d\n", "INT", res);
            //printf("%s",root->yytext);
        }
        else if(strcmp("INT16",root->name) == 0)
        {
            // 处理十六进制整数，转换为十进制并打印
            char * temp = root->yytext;
            temp++;temp++;
            char * end =NULL;
            int res = strtol(temp,&end,16);
            printf("%s: %d\n", "INT", res);
            //printf("%s",root->yytext);
        }
        else if(strcmp("FLOAT",root->name) == 0)
        {
            printf("%s: %f\n", root->name, atof(root->yytext));
        }
        else
        {
            printf("%s\n", root->name);
        }
        
    }
}